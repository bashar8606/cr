"use client"
import Image from "next/image";
import style from "./HomeJoin.module.scss";
import EnquireModal from "../EnquireModal";


const HomeJoin = ({ data, id }) => {
	return (
		<section className={`${style.section} sec-padding`} id={id}>
			<div className="container">
				<div className="row align-items-center justify-content-between gy-1 ">
					<div className="col-lg-5 ">
						<h3 className="h2 fw-500 mb-0">Start your journey with Edunest today.</h3>
					</div>
					<div className="col-lg-5 ">
						<p className="title-md fw-300 ">Create a free account so you can save your progress any time and access thousands of maths resources for you to customise and share with others.</p>
						<EnquireModal/>
					</div>
				</div>
			</div>
			
		</section>
	);
};

export default HomeJoin;