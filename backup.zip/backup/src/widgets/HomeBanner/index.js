"use client"
import Image from "next/image";
import style from "./HomeBanner.module.scss";
import { BiSolidQuoteAltRight } from "react-icons/bi";
import { useHomeBanner } from "./useHomeBanner";
import EnquireModal from "../EnquireModal";


const HomeBanner = ({ data }) => {
	const { main, width } = useHomeBanner({ style });

	return (
		<section className={`${style.section} d-flex align-items-center overflow-hidden flex-column  position-relative pb-5 pb-lg-4 pt-3 pt-lg-3`} ref={main} >
			<div className={`position-absolute start-50 ${style.globe}`}>
				<div className="ratio ratio-1x1">
					<Image src={`/assets/images/globe.svg`} priority={true} fill className="object-fit-contain" alt={``} />
				</div>
			</div>
			<div className="position-relative justify-content-center container w-100 col d-flex align-items-center ">
				{width >= 992 &&
					<>
						<div className={`position-absolute  ${style.p} ${style.p1}`}>
							<div className="ratio">
								<Image src={`/assets/images/m1.png`} priority={true} fill className="object-fit-contain" alt={``} />
							</div>
						</div>

						<div className={`position-absolute ${style.p} ${style.p2}`}>
							<div className="ratio">
								<Image src={`/assets/images/m2.png`} priority={true} fill className="object-fit-contain" alt={``} />
							</div>
						</div>
					</>}



				<div className="pb-lg-5">
					<div className="row">
						<div className="col-lg-8 mx-auto text-center pb-lg-5">
							{width>992?"":
							<div className="row row-cols-2 gx-3 mb-4">
								<div>
									<div className={` ${style.p} ${style.p1}`}>
										<div className="ratio">
											<Image src={`/assets/images/m1.png`} priority={true} fill className="object-fit-contain" alt={``} />
										</div>
									</div>
								</div>
								<div>
									<div className={` ${style.p} ${style.p2}`}>
										<div className="ratio">
											<Image src={`/assets/images/m2.png`} priority={true} fill className="object-fit-contain" alt={``} />
										</div>
									</div>
								</div>
							</div>}
							<h1 className={`${style.title} ${style.fade}   lh-sm mb-3 mb-lg-4 fw-400 text-white`}>Learn Virtually<br /> with EduNest!</h1>
							<div className={`${style.fade} `}>
								<p className={`title-md fw-300 text-white opacity-75 col-lg-9 mx-auto mb-3 mb-lg-4  `}>
								Embark on a virtual journey of discovery and learning.
									Join EduNest for immersive learning experiences from the comfort of your home.
								</p>
							</div>
							<div className={`${style.fade}`}>
								<EnquireModal isLight={true}/>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
};

export default HomeBanner;


const faculties = {
	title: "",
	data: [
		{
			url: "/assets/images/p1.png",
			alt: ""
		}, {
			url: "/assets/images/p2.png",
			alt: ""
		}, {
			url: "/assets/images/p3.png",
			alt: ""
		}, {
			url: "/assets/images/p4.png",
			alt: ""
		},
	]
}