import { Expo, gsap } from "gsap";
import { useLayoutEffect, useRef, useState } from "react";
import { EffectFade, Navigation, Pagination, Autoplay } from 'swiper/modules';
import 'swiper/css/effect-fade';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/autoplay';

gsap.config({ force3D: true });
export const useHomeAbout = ({ style }) => {

  const main = useRef(null);

  const customSettings = {
    spaceBetween: 15,
    slidesPerView: 1.3,
    breakpoints: {
      640: {
        spaceBetween: 2,
      },
      768: {
        slidesPerView: 2.2,
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 20
      },
    },
    pagination: false,
  };


  return {
    main,
    customSettings,
  };
};
