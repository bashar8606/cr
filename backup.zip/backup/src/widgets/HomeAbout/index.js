"use client"
import style from "./HomeAbout.module.scss";
import { useHomeAbout } from "./useHomeAbout";
import { PiStudentBold } from "react-icons/pi";
import SpecCard from "@/components/SpecCard";
import { FaChalkboardTeacher } from "react-icons/fa";
import { MdSupport } from "react-icons/md";
import { LuAlarmClock } from "react-icons/lu";
import Slider from "@/components/Slider";
import { SwiperSlide } from "swiper/react";
const HomeAbout = ({ data }) => {
	const { main, customSettings } = useHomeAbout({ style });
	return (
		<section className={`${style.section}  position-relative`} ref={main}>
			<div className="container">
				<Slider className={''} customSettings={customSettings}>
					<SwiperSlide className={`h-auto ${style.slider_item}`}><SpecCard title="Expert Instructor" theme="one"  icon={'/assets/images/f1.svg'}  bg={'/assets/images/s1.svg'} /></SwiperSlide>
					<SwiperSlide className={`h-auto ${style.slider_item}`}><SpecCard title="24/7 Support "  theme="two" icon={'/assets/images/f2.svg'} bg={'/assets/images/s2.svg'} /></SwiperSlide>
					<SwiperSlide className={`h-auto ${style.slider_item}`}><SpecCard title="Lifetime Access"  theme="three" icon={'/assets/images/f3.svg'} bg={'/assets/images/s3.svg'} /></SwiperSlide>
				</Slider>
			</div>
		</section>
	);
};

export default HomeAbout;
