"use client"
import Image from "next/image";
import style from "./HomeLearn.module.scss";
import { Modal } from "react-bootstrap";
import Link from "next/link";
import EnquireModal from "../EnquireModal";


const HomeLearn = ({ data, id }) => {
	return (
		<section className={`${style.section} sec-padding`} id={id}>
			<div className="container">
				<div className="bg-white overflow-hidden">
					<div className="row align-items-center">
						<div className="col-lg-6">
							<div className="ratio ratio-1x1">
								<Image src={'/assets/images/text_shape.svg'} priority={true} fill className="object-fit-contain" alt={``} />

							</div>
						</div>
						<div className="col-lg-6">


							<div className="col-lg-8 mx-auto py-5">
								<h3 className="h3 fw-500 mb-4 mb-lg-5 text-center">Learn Virtually<br />
									with <span className="text-primary">EduNest!</span></h3>


								<div className={`${style.tab_screen} position-relative ratio mb-lg-5 mb-4`}>
									<div>

										{faculties?.data?.map((item, i) => {
											return (
												<div key={i} className={`${style.pf_sm} d-inline-block rounded-circle overflow-hidden bg-light  ratio ratio-1x1 position-absolute`}>
													<Image src={`${item?.url}`} priority={true} fill className="object-fit-cover" alt={`${item?.alt}`} />
												</div>
											)
										})}

									</div>


									<div className={`${style.tab_screen__frame} z-3`}>
										<Image src={`/assets/images/laptop.png`} priority={true} fill alt="logo" />
									</div>
									<div className={style.tab_screen__video}>
										<div className={`d-flex align-items-end pb-2 px-3  bottom-0  ${style.tab_screen__control} z-3 position-absolute justify-content-center`}>
											<div className={style.item_wrap}>
												<div className={`${style.item} ratio bg-white ratio-1x1 overflow-hidden d-inline-block rounded-circle`}>
													<Image src={`/assets/images/icons/icon-speaker.svg`} className={style.tab_icon} fill alt="logo" />
												</div>
												<div className={`${style.item} ratio bg-white ratio-1x1 overflow-hidden d-inline-block rounded-circle`}>
													<Image src={`/assets/images/icons/icon-video.svg`} className={style.tab_icon} fill alt="logo" />
												</div>
												<div className={`${style.item} ratio  ratio-1x1 overflow-hidden d-inline-block rounded-circle`}>
													<Image src={`/assets/images/icons/icon-mic.svg`} className={style.tab_icon} fill alt="logo" />
												</div>
												<div className={`${style.item} ratio  ratio-1x1 overflow-hidden d-inline-block rounded-circle`}>
													<Image src={`/assets/images/icons/icon-close.svg`} className={style.tab_icon} fill alt="logo" />
												</div>
											</div>



										</div>
										<div className={`${style.video_wrap} w-100 h-100 overflow-hidden position-relative`}>
											<video width={`100%`}
												height={`100%`}
												loop
												muted
												autoPlay
												playsInline
												className="object-fit-cover position-absolute top-0 start-0 w-100 h-100"
												src="/assets/images/video.mp4">
											</video>
										</div>
									</div>
								</div>

								<div className="text-center">
									<EnquireModal />
								</div>
							</div>





						</div>
					</div>


				</div>
			</div>

		</section>
	);
};

export default HomeLearn;

const faculties = {
	title: "",
	data: [
		{
			url: "/assets/images/p1.png",
			alt: ""
		}, {
			url: "/assets/images/p2.png",
			alt: ""
		}, {
			url: "/assets/images/p3.png",
			alt: ""
		}, {
			url: "/assets/images/p4.png",
			alt: ""
		},
	]
}