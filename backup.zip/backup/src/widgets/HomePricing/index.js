"use client"
import Image from "next/image";
import { useHomePricing } from "./useHomePricing";
import style from "./HomePricing.module.scss";
import { TiTick } from "react-icons/ti";
import Slider from "@/components/Slider";
import CourseCard from "@/components/CourseCard";
import { SwiperSlide } from "swiper/react";


const HomePricing = ({ data, id }) => {
	const { main, customSettings  } = useHomePricing(style);
	return (
		<section className={`${style.section} sec-padding  overflow-hidden`} id={id} ref={main}>
			<div className="container">
				<div className="row align-items-center justify-content-between gy-1 mb-4 mb-lg-5">
				<div className="col-lg-6 ">
					<h2 className="text-primary h5 mb-2">About Us</h2>
					<h3 className="h2 fw-500 mb-0">Your virtual classroom for limitless learning!</h3>
				</div>
				<div className="col-lg-4 ">
					<p className="title-md fw-300 mb-0">Fostering a love for learning is at the heart of our mission. We believe in nurturing every child&apos;s curiosity, imagination, and creativity, empowering them to become confident, well-rounded individuals who are eager to explore the world around them</p>
				</div>
				</div>
				<Slider className={'overflow-visible'} customSettings={customSettings}>
					{course?.map((item, i)=>{
						return(
							<SwiperSlide key={i} className={`h-auto ${style.slider_item}`}><CourseCard title={item?.title} content={item?.description} img={item?.img} theme={item?.theme} /></SwiperSlide>
						)
					})}
				</Slider>


			</div>
		</section>
	);
};

export default HomePricing;

const course = [
	{
		title: "Maths Resources",
		description: "Get access to comprehensive materials and tools to enhance your understanding of mathematics.		",
		img:"/assets/images/i1.png",
	},{
		title: "Maths Calculators & Apps",
		description: "Use our calculators and apps designed for complex mathematical problems including 3D calculations.		",
		img:"/assets/images/i2.png",
	},{
		title: "Classroom Collaboration",
		description: "Our interactive tools foster collaboration and engagement in the math classroom.		",
		img:"/assets/images/i3.png",
	},{
		title: "Math Practice",
		description: "Extensive practice exercises to strengthen math skills and boost confidence.",
		img:"/assets/images/i4.png",
	}
]


