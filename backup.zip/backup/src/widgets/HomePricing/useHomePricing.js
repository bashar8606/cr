import { useLayoutEffect, useRef, useState } from "react";
import { Elastic, Expo, Power3, Power4, gsap } from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { Autoplay } from "swiper/modules";

gsap.config({ force3D: true });
export const useHomePricing = (style) => {
  gsap.registerPlugin(ScrollTrigger);
  const main = useRef(null);

  const customSettings = {
    spaceBetween: 15,
    modules: [Autoplay],
    autoplay: true,
    slidesPerView: 1.3,
    breakpoints: {
      640: {
        spaceBetween: 2,
      },
      768: {
        slidesPerView: 2.5,
        spaceBetween: 20
      },
      1200: {
        slidesPerView: 4,
        spaceBetween: 40
      },
    },
    pagination: false,
  };

  return {
    main,
    customSettings
  };
};
